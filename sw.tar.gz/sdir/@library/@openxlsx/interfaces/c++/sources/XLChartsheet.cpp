//
// Created by Troldal on 2019-01-28.
//

#include "XLChartsheet.h"
#include "XLChartsheet_Impl.h"

using namespace OpenXLSX;

XLChartsheet::XLChartsheet(Impl::XLSheet& sheet)
        : XLSheet(sheet) {

}
